import React, { useState, useEffect } from 'react';
import { Lock, Clock, Users, Shield, Smartphone, Eye, Heart, Star } from 'lucide-react';

function App() {
  const [timeLeft, setTimeLeft] = useState({ hours: 1, minutes: 23, seconds: 47 });
  const [accessLeft, setAccessLeft] = useState(3);
  const [viewCount, setViewCount] = useState(4892);

  // Contagem regressiva falsa
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Aumentar visualizações periodicamente
  useEffect(() => {
    const viewTimer = setInterval(() => {
      setViewCount(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 15000);

    return () => clearInterval(viewTimer);
  }, []);

  // Diminuir acessos restantes periodicamente
  useEffect(() => {
    const accessTimer = setInterval(() => {
      setAccessLeft(prev => prev > 1 ? prev - 1 : 1);
    }, 120000); // A cada 2 minutos

    return () => clearInterval(accessTimer);
  }, []);

  const handleCTAClick = () => {
    // Redireciona para o link do Cakto
    window.open('https://pay.cakto.com.br/yg2pcok_431550', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      {/* Header */}
      <header className="bg-black/80 backdrop-blur-sm shadow-xl sticky top-0 z-50 border-b border-purple-500/20">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Lock className="h-8 w-8 text-pink-500" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Conteúdo+ Exclusivo
              </h1>
            </div>
            <div className="hidden md:flex items-center space-x-4 text-sm">
              <span className="flex items-center space-x-1 text-pink-300">
                <Heart className="h-4 w-4" />
                <span>+18 Anos</span>
              </span>
              <span className="flex items-center space-x-1 text-purple-300">
                <Shield className="h-4 w-4" />
                <span>100% Privado</span>
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="text-sm text-gray-400 mb-6">
          <span>Início</span> <span className="mx-2 text-pink-500">›</span> 
          <span>Entretenimento</span> <span className="mx-2 text-pink-500">›</span>
          <span className="text-pink-400">Acesso VIP</span>
        </nav>

        {/* Article */}
        <article className="bg-black/60 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden border border-purple-500/20">
          <div className="p-6 md:p-8">
            {/* Meta Info */}
            <div className="flex items-center justify-between mb-6 text-sm">
              <div className="flex items-center space-x-4 text-gray-300">
                <span>Por: Redação VIP</span>
                <span>•</span>
                <span>Agora mesmo</span>
                <span>•</span>
                <span className="bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                  🔥 QUENTE
                </span>
              </div>
              <div className="flex items-center space-x-1 text-pink-400">
                <Eye className="h-4 w-4" />
                <span>{viewCount.toLocaleString()} views</span>
              </div>
            </div>

            {/* Main Title */}
            <h1 className="text-3xl md:text-5xl font-bold text-white leading-tight mb-6">
              <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                O conteúdo mais desejado
              </span>
              <br />
              <span className="text-white">
                que está deixando todo mundo 
                <span className="text-pink-400"> obcecado</span>
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Acesso VIP vitalício ao que há de mais <span className="text-pink-400 font-semibold">provocante e exclusivo</span>. 
              Navegação ultra-discreta e conteúdo que você não encontra em lugar nenhum.
            </p>

            {/* Hero Image */}
            <div className="mb-8 rounded-xl overflow-hidden relative group">
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10"></div>
              <img 
                src="/image.png"
                alt="Conteúdo exclusivo e provocante"
                className="w-full h-64 md:h-96 object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute bottom-4 left-4 z-20 text-white">
                <p className="text-sm font-medium">
                  💎 Conteúdo premium e provocante
                </p>
              </div>
            </div>

            {/* Urgency Banner */}
            <div className="bg-gradient-to-r from-red-600 via-pink-600 to-purple-600 text-white rounded-xl p-6 mb-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-purple-600/20 animate-pulse"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                    <span className="font-bold text-lg">🔥 ÚLTIMAS HORAS - Oferta Imperdível</span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm bg-black/30 rounded-lg px-4 py-2">
                    <div className="text-center">
                      <div className="font-bold text-2xl">{String(timeLeft.hours).padStart(2, '0')}</div>
                      <div className="text-xs opacity-75">horas</div>
                    </div>
                    <div className="text-white/50">:</div>
                    <div className="text-center">
                      <div className="font-bold text-2xl">{String(timeLeft.minutes).padStart(2, '0')}</div>
                      <div className="text-xs opacity-75">min</div>
                    </div>
                    <div className="text-white/50">:</div>
                    <div className="text-center">
                      <div className="font-bold text-2xl">{String(timeLeft.seconds).padStart(2, '0')}</div>
                      <div className="text-xs opacity-75">seg</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Article Content */}
            <div className="prose prose-lg max-w-none mb-8 text-gray-300">
              <p className="leading-relaxed mb-6">
                Nos últimos meses, uma comunidade ultra-exclusiva tem causado <strong className="text-pink-400">furor total</strong> entre 
                pessoas que buscam o que há de mais <strong className="text-purple-400">provocante e irresistível</strong> na internet. 
                O que começou como um pequeno círculo íntimo, hoje reúne os conteúdos mais <strong className="text-pink-400">desejados e cobiçados</strong>.
              </p>

              <p className="leading-relaxed mb-6">
                A plataforma oferece <strong className="text-purple-400">acesso vitalício</strong> a uma biblioteca que vai te deixar 
                <strong className="text-pink-400"> completamente viciado</strong>. Todo o material é cuidadosamente selecionado para 
                proporcionar a <strong className="text-purple-400">experiência mais intensa</strong> possível, com total discrição e privacidade.
              </p>

              <div className="bg-gradient-to-r from-pink-900/40 to-purple-900/40 border border-pink-500/30 rounded-xl p-6 mb-6">
                <div className="flex items-start space-x-3">
                  <Star className="h-5 w-5 text-yellow-400 mt-1 flex-shrink-0" />
                  <p className="text-pink-200 italic font-medium">
                    "Nunca imaginei que existisse algo tão <span className="text-pink-400">intenso e viciante</span>. 
                    É impossível parar de acessar. A qualidade é <span className="text-purple-400">absolutamente insana</span>!" 
                    <br />
                    <span className="text-sm text-gray-400 mt-2 block">- Membro VIP verificado ⭐</span>
                  </p>
                </div>
              </div>

              <p className="leading-relaxed mb-8">
                O diferencial está na <strong className="text-pink-400">curadoria impecável e acesso instantâneo</strong>. 
                Sem enrolação, sem cadastros complicados, apenas acesso direto ao que realmente 
                <strong className="text-purple-400"> vai te deixar sem fôlego</strong>. A comunidade mantém os mais altos 
                padrões de qualidade e <strong className="text-pink-400">conteúdo de tirar o sono</strong>.
              </p>
            </div>

            {/* Access Counter */}
            <div className="bg-gradient-to-r from-amber-900/60 to-red-900/60 border border-amber-500/30 rounded-xl p-6 mb-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-600/10 to-red-600/10 animate-pulse"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
                  <span className="font-bold text-amber-200 text-lg">⚡ ATENÇÃO: Restam apenas {accessLeft} acessos VIP hoje!</span>
                </div>
                <p className="text-sm text-amber-300">
                  Devido à <strong>demanda insana</strong>, limitamos os acessos diários para manter a exclusividade total
                </p>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="text-center p-6 bg-gradient-to-br from-purple-900/40 to-pink-900/40 rounded-xl border border-purple-500/20 hover:border-pink-500/40 transition-all duration-300">
                <Smartphone className="h-10 w-10 text-pink-400 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-2">Mobile VIP</h3>
                <p className="text-sm text-gray-300">Experiência otimizada para celular</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-green-900/40 to-emerald-900/40 rounded-xl border border-green-500/20 hover:border-emerald-500/40 transition-all duration-300">
                <Shield className="h-10 w-10 text-emerald-400 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-2">Ultra Discreto</h3>
                <p className="text-sm text-gray-300">Navegação 100% anônima</p>
              </div>
              <div className="text-center p-6 bg-gradient-to-br from-purple-900/40 to-indigo-900/40 rounded-xl border border-purple-500/20 hover:border-indigo-500/40 transition-all duration-300">
                <Lock className="h-10 w-10 text-indigo-400 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-2">Acesso Vitalício</h3>
                <p className="text-sm text-gray-300">Pague uma vez, acesse para sempre</p>
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center bg-gradient-to-br from-pink-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600/20 to-purple-600/20 animate-pulse"></div>
              <div className="relative z-10">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">
                  🔥 Pronto para a experiência mais 
                  <span className="text-pink-300"> intensa</span> da sua vida?
                </h2>
                <p className="text-xl opacity-90 mb-8">
                  Junte-se a <strong>milhares de membros VIP</strong> que já descobriram o conteúdo mais 
                  <span className="text-pink-300 font-semibold"> provocante e exclusivo</span> da internet
                </p>
                
                <button 
                  onClick={handleCTAClick}
                  className="group inline-flex items-center space-x-3 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-400 hover:to-red-400 text-white font-bold text-xl px-10 py-5 rounded-full transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-pink-500/25 border-2 border-pink-400/50"
                >
                  <Lock className="h-6 w-6 group-hover:animate-pulse" />
                  <span>🔓 LIBERAR ACESSO VIP AGORA</span>
                  <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                </button>
                
                <div className="flex items-center justify-center space-x-6 text-sm opacity-90 mt-6 flex-wrap gap-2">
                  <span className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Acesso imediato</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Sem mensalidade</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>100% discreto</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </article>

        {/* Trust Signals */}
        <div className="mt-8 text-center">
          <div className="flex items-center justify-center space-x-8 text-sm text-gray-400 flex-wrap gap-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-green-400" />
              <span>SSL Seguro</span>
            </div>
            <div className="flex items-center space-x-2">
              <Lock className="h-4 w-4 text-purple-400" />
              <span>Dados Protegidos</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-pink-400" />
              <span>+25.000 membros VIP</span>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="h-4 w-4 text-yellow-400" />
              <span>98% satisfação</span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/80 backdrop-blur-sm text-white mt-16 border-t border-purple-500/20">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="relative">
                <Lock className="h-8 w-8 text-pink-500" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Conteúdo+ Exclusivo
              </span>
            </div>
            
            <div className="border-t border-gray-700 pt-6 mt-6">
              <p className="text-lg text-pink-300 mb-3 font-semibold">
                🔞 Esta página é destinada exclusivamente para maiores de 18 anos.
              </p>
              <p className="text-sm text-gray-400 mb-6">
                Conteúdo ultra-exclusivo e provocante. Navegação privada e discreta garantida.
                <br />
                <span className="text-pink-400">Prepare-se para uma experiência que vai mudar tudo.</span>
              </p>
              
              <div className="flex items-center justify-center space-x-6 text-xs text-gray-500 mb-4">
                <span className="hover:text-pink-400 cursor-pointer transition-colors">Termos de Uso</span>
                <span>•</span>
                <span className="hover:text-pink-400 cursor-pointer transition-colors">Privacidade</span>
                <span>•</span>
                <span className="hover:text-pink-400 cursor-pointer transition-colors">Contato VIP</span>
              </div>
              
              <p className="text-xs text-gray-500">
                © 2024 Conteúdo+ Exclusivo. Todos os direitos reservados. 
                <span className="text-pink-400"> Experiência premium garantida.</span>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;